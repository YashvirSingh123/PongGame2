
public class TestingResizeImage {

}
